<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Bootstrap 101 Template</title>

    <!-- Bootstrap -->
    <link href="{{ asset('assets/css/bootstrap.css') }}" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
    <div class="container">
        <input type="text" id="start_point" value="-8.673390,115.226744">
        <input type="button" id="use_current_location" value="gunakan lokasi anda">
        <select class="form-control" id="end_point"><option value="">-- Silahkan Pilih --</option></select>        
    </div>
    
  
    <div class="container" style="margin-top:40px;">
        <div id="myMap" style="height:500px; width:1140px;"></div>
    </div>

    <div id="right-panel" class="container" style="
    width: 526px;
    float: left;
    direction: ltr;
    margin-left: 88px;
    margin-top: 20px;">
    </div>
    
        <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script>
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
        <script src="{{ asset('assets/js/bootstrap.min.js') }}"></script>
        <script type="text/javascript"> 

        // inisial variables
            var datas;
            var map;
            var markers = [];
            var myLatlng = new google.maps.LatLng(-8.673390,115.226744);
            var infowindow = new google.maps.InfoWindow();

        // direction maps
            var directionsDisplay = new google.maps.DirectionsRenderer({
                suppressMarkers: true,
            });
            var directionsService = new google.maps.DirectionsService;

        // map options
            function initialize(){
                var mapOptions = {
                    zoom: 10,
                    center: myLatlng,
                    mapTypeId: google.maps.MapTypeId.ROADMAP
                };
           
                map = new google.maps.Map(document.getElementById("myMap"), mapOptions);

        // detail direction

                directionsDisplay.setMap(map);
                directionsDisplay.setPanel(document.getElementById('right-panel')); 

        // event onchange
                var onChangeHandler = function() {
                    calculateAndDisplayRoute(directionsService, directionsDisplay);
                };
                document.getElementById('start_point').addEventListener('change', onChangeHandler);
                document.getElementById('end_point').addEventListener('change', onChangeHandler);

                jQuery.ajax({
                    url : '{{ URL::to("apijson") }}',
                    type : 'get',
                    dataType : 'JSON',
                    success : function(data){
                        datas = data;
                        constructMarker();
                    }
                });
            }

        // fungsi tambah info window
            function constructWindow(marker , map ,infowindow , model){
                return function(){
                    infowindow.setContent('<ul> <li>Nama : '+ model.name +'</li> <li>Alamat : '+ model.address +'</li> </ul>');
                    infowindow.open(map , marker);
                }
            }

        // fungsi tambah marker
            function constructMarker(){
                for(var index in datas){
                    var option = '<option value="'+datas[index].latitude+', '+datas[index].longitude+'">'+datas[index].name+'</option>';
                   
                   jQuery(option).appendTo('#end_point');

        // show array data json
                    var marker = new google.maps.Marker({
                        map : map,
                        position : new google.maps.LatLng(
                            datas[index].latitude , 
                            datas[index].longitude
                        ),
                        draggable : false
                        
                    });

                    //markers.push(marker);
                    markers[index] = marker;

                    google.maps.event.addListener(
                        marker , 
                        'click' ,                                           
                        constructWindow(marker , map , infowindow , datas[index] )
                    );

                }
            }
            
            function calculateAndDisplayRoute(directionsService, directionsDisplay) {
              var start = document.getElementById('start_point').value;
              var end = document.getElementById('end_point').value;
              directionsService.route({
                origin: start,
                destination: end,
                travelMode: google.maps.TravelMode.DRIVING
              }, function(response, status) {
                if (status === google.maps.DirectionsStatus.OK) {
                  directionsDisplay.setDirections(response);
                } else {
                  window.alert('Directions request failed due to ' + status);
                }
              });


            }

            google.maps.event.addDomListener(window, 'load', initialize);

            $(function(){
                jQuery('#use_current_location').click(function(){
                    if (navigator.geolocation) {
                        console.log('geo loc. supportted');
                        navigator.geolocation.getCurrentPosition(function(position) {
                            var pos = {
                                lat: position.coords.latitude,
                                lng: position.coords.longitude
                            };

                            console.log(pos);
                            jQuery('#start_point').val(pos.lat+','+pos.lng);

                            var end = jQuery('#end_point').val();
                            if(end!==''){
                                calculateAndDisplayRoute(directionsService, directionsDisplay);
                            }
                        }, function() {
                           console.log('get location error');
                        });
                    }else{
                        console.log('geo loc. not supportted');
                    }
                });
            });

        </script> 

  </body>
</html>