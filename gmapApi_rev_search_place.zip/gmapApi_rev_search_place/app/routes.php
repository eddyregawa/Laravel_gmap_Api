<?php

Route::get('/', function()
{
	return View::make('hello');
});

Route::get('/form', [
	'uses' => 'ControllerGis@index',
	'as'   => 'form'
]);

Route::post('/save', [
	'uses' => 'ControllerGis@save',
	'as'   => 'save'
]);

Route::get('/tampil', [
	'uses' => 'ControllerGis@viewdata',
	'as'   => 'tampil'
]);

Route::get('/apijson' , [
	'uses' => 'ControllerGis@json',
	'as'   => 'apijson'
]);