<?php

class ControllerGis extends \BaseController {
	
	public function index()
	{
		return View::make('place.form');
	}

	public function save()
	{
		$data = Input::all();
		$simpan = DB::table('place')->insert($data);
		if($simpan>0)
		{
			$message = 'Penyimpanan Berhasil';
		}
		else
		{
			$message = 'Penyimpanan gagal';
		}
		return $message;

	}

	public function viewdata()
	{
		
		return View::make('tampil');
		

	}

	public function json(){
		$datatampil    = DB::table('place')->get();
		$datajsontmpil = json_encode($datatampil);
		echo $datajsontmpil;	
	}

}